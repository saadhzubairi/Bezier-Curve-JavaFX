package com.example.cg_assignment;

public class Main_1 {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
